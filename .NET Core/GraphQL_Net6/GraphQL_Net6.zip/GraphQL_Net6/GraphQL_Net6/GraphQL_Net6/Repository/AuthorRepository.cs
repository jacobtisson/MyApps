﻿using GraphQL_Net6.Entities;
using GraphQL_Net6.Entities.Models.Author;
using GraphQL_Net6.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace GraphQL_Net6.Repository
{
    public class AuthorRepository : IAuthorService
    {
        private readonly ApplicationDBContext _context;
        public AuthorRepository(ApplicationDBContext context)
        {
            _context = context;
        }

        public Task<List<Author>> GetAuthorsAsyn()
        {
            try
            {
                return Task.FromResult(_context.Authors.ToList());
            }
            catch (Exception) { throw; }
        }

        public Task<Author?> GetAuthorByIdAsyn(Guid authorId)
        {
            try
            {
                return Task.FromResult(_context.Authors.FirstOrDefault(a => a.Id == authorId));               
            }
            catch (Exception) { throw; }
        }

        public async Task<AuthorPayload> AddAuthorAsyn(AuthorInput authorInput)
        {
            try
            {
                //Add Author
                var author = new AuthorPayload();
                author.Id = Guid.NewGuid();
                author.Name = authorInput.Name;
                author.Description = authorInput.Description;

                _context.Authors.Add(author);
                _context.SaveChanges();
                return author;
            }
            catch (Exception) { throw; }
        }

        public async Task<AuthorUploadPayload> UpdateAuthorAsyn(AuthorUpdateInput authorUpdateInput)
        {
            try
            {
                var author = await GetAuthorByIdAsyn(authorUpdateInput.Id) ??
                       throw new Exception("Author not found");

                //Update Author
                author.Name = authorUpdateInput.Name;
                author.Description = authorUpdateInput.Description;

                _context.Entry(author).State = EntityState.Modified;                
                _context.SaveChanges();

                var updatedAuthor = new AuthorUploadPayload();
                updatedAuthor.Id= author.Id;
                updatedAuthor.Name = authorUpdateInput.Name;
                updatedAuthor.Description = authorUpdateInput.Description;
                return updatedAuthor;
            }
            catch (Exception) { throw; }
        }
    }
}
