﻿using GraphQL_Net6.Entities;
using GraphQL_Net6.Entities.Models.Author;
using GraphQL_Net6.Entities.Models.Book;
using GraphQL_Net6.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace GraphQL_Net6.Repository
{
    public class BookRepository : IBookService 
    {
        private readonly ApplicationDBContext _context;
        private readonly IAuthorService _authorService;
        public BookRepository(ApplicationDBContext context, IAuthorService authorService)
        {
            _context = context;
            _authorService = authorService;
        }

        public Task<List<Book>> GetBooksAsyn()
        {
            try
            {
                return Task.FromResult(_context.Books.ToList());
            }
            catch (Exception) { throw; }
        }

        public Task<Book?> GetBookByIdAsyn(Guid bookId)
        {
            try
            {
                return Task.FromResult(_context.Books.FirstOrDefault(a => a.Id == bookId));
            }
            catch (Exception) { throw; }
        }

        public async Task<BookPayload> AddBookAsyn(BookInput bookInput)
        {
            try
            {
                var author = await _authorService.GetAuthorByIdAsyn(bookInput.AuthorId) ??
                       throw new Exception("Author not found");
                //Add Book
                var book = new BookPayload();
                book.Id = Guid.NewGuid();
                book.Title = bookInput.Title;
                book.Description = bookInput.Description;
                book.AuthorId = author.Id;

                _context.Books.Add(book);
                _context.SaveChanges();
                return book;
            }
            catch (Exception) { throw; }
        }

        public async Task<BookUpdatePayload> UpdateBookAsyn(BookUpdateInput bookUpdateInput)
        {
            try
            {                
                var book = await GetBookByIdAsyn(bookUpdateInput.Id) ??
                       throw new Exception("Book not found");

                //Update Book                
                book.Title = bookUpdateInput.Title;
                book.Description = bookUpdateInput.Description;
                book.AuthorId = bookUpdateInput.AuthorId;

                _context.Entry(book).State = EntityState.Modified;
                _context.SaveChanges();

                var updatedBook = new BookUpdatePayload();
                updatedBook.Id = bookUpdateInput.Id;
                updatedBook.Title = bookUpdateInput.Title;
                updatedBook.Description = bookUpdateInput.Description;
                updatedBook.AuthorId = bookUpdateInput.AuthorId;
                return updatedBook;
            }
            catch (Exception) { throw; }
        }

        public async Task DeleteBookAsyn(Guid bookId)
        {
            var book = await GetBookByIdAsyn(bookId) ??
                       throw new Exception("Book not found");

            _context.Books.Remove(book);
            _context.SaveChanges();            
        }
    }
}
