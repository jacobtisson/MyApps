﻿using GraphQL_Net6.Entities.Models.Author;
using GraphQL_Net6.Entities.Models.Book;
using GraphQL_Net6.Interfaces;

namespace GraphQL_Net6.GraphQL.GraphQLMutation
{
    [ExtendObjectType(typeof(RootMutation))]
    public class AuthorMutation
    {
        public Task<AuthorPayload> AddAuthor(AuthorInput authorInput, [Service] IAuthorService authorService)
            => authorService.AddAuthorAsyn(authorInput);

        public Task<AuthorUploadPayload> UpdateAuthor(AuthorUpdateInput updateAuthorInput, [Service] IAuthorService authorService)
          => authorService.UpdateAuthorAsyn(updateAuthorInput);
    }
}
