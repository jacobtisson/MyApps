﻿
using GraphQL_Net6.Entities.Models.Book;
using GraphQL_Net6.Interfaces;

namespace GraphQL_Net6.GraphQL.GraphQLMutation
{
    [ExtendObjectType(typeof(RootMutation))]
    public class BookMutation
    {
        public Task<BookPayload> AddBook(BookInput bookInput, [Service] IBookService bookService)
            => bookService.AddBookAsyn(bookInput);

        public Task<BookUpdatePayload> UpdateBook(BookUpdateInput updateBookInput, [Service] IBookService bookService)
           => bookService.UpdateBookAsyn(updateBookInput);

        public Task DeleteBook(Guid bookId, [Service] IBookService bookService)
          => bookService.DeleteBookAsyn(bookId);
    }
}
