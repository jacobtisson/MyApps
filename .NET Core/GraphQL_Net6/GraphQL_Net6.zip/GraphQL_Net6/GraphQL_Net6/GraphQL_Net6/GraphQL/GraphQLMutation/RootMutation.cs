﻿namespace GraphQL_Net6.GraphQL.GraphQLMutation
{
    public class RootMutation
    {
    }
}
