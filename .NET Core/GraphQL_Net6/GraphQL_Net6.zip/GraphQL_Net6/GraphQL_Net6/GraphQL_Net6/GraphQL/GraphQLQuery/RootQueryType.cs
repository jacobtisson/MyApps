﻿namespace GraphQL_Net6.GraphQL.GraphQLTypes
{
    public class RootQueryType
    {       
    }
}
