﻿using GraphQL_Net6.Entities.Models.Book;
using GraphQL_Net6.Interfaces;
using GraphQL_Net6.GraphQL.GraphQLTypes;
using GraphQL_Net6.Entities.Models.Author;

namespace GraphQL_Net6.GraphQL.GraphQLQuery
{
    [ExtendObjectType(typeof(RootQueryType))]
    public class BookQueryType
    {
        public Task<List<Book>> GetBooks([Service] IBookService bookService, CancellationToken cancellationToken = default) =>
        bookService.GetBooksAsyn();

        public Task<Book?> GetBookById(Guid bookId, [Service] IBookService bookService, CancellationToken cancellationToken = default) =>
        bookService.GetBookByIdAsyn(bookId);
    }
}
