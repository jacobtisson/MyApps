﻿using GraphQL_Net6.Entities.Models.Author;

using GraphQL_Net6.Interfaces;
using GraphQL_Net6.GraphQL.GraphQLTypes;

namespace GraphQL_Net6.GraphQL.GraphQLQuery
{
    [ExtendObjectType(typeof(RootQueryType))]
    public class AuthorQueryType : RootQueryType
    {
        public Task<List<Author>> GetAuthors([Service] IAuthorService authorService, CancellationToken cancellationToken = default) =>
        authorService.GetAuthorsAsyn();

        public Task<Author?> GetAuthorById(Guid authorId, [Service] IAuthorService authorService, CancellationToken cancellationToken = default) =>
        authorService.GetAuthorByIdAsyn(authorId);
    }
}
