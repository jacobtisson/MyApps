﻿using GraphQL_Net6.Entities.Models.Book;

namespace GraphQL_Net6.Interfaces
{
    public interface IBookService
    {
        public Task<List<Book>> GetBooksAsyn();
        public Task<Book?> GetBookByIdAsyn(Guid authorId);
        public Task<BookPayload> AddBookAsyn(BookInput bookInput);
        public Task<BookUpdatePayload> UpdateBookAsyn(BookUpdateInput bookUpdateInput);
        public Task DeleteBookAsyn(Guid bookId);
    }
}
