﻿using GraphQL_Net6.Entities.Models.Author;

namespace GraphQL_Net6.Interfaces
{
    public interface IAuthorService
    {
        public Task<List<Author>> GetAuthorsAsyn();
        public Task<Author?> GetAuthorByIdAsyn(Guid authorId);
        public Task<AuthorPayload> AddAuthorAsyn(AuthorInput authorInput);
        public Task<AuthorUploadPayload> UpdateAuthorAsyn(AuthorUpdateInput authorUpdateInput);
    }
}
