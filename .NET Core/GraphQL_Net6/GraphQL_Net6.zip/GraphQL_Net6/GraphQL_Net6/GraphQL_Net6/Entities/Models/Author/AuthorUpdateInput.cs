﻿namespace GraphQL_Net6.Entities.Models.Author
{
    public class AuthorUpdateInput : Author
    {
    }
}
