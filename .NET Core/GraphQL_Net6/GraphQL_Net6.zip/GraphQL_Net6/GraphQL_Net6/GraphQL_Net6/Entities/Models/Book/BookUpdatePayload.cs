﻿namespace GraphQL_Net6.Entities.Models.Book
{
    public class BookUpdatePayload : Book
    {        
    }
}
