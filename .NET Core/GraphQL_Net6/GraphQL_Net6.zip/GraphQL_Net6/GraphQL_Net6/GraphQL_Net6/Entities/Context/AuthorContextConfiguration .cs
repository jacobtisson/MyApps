﻿
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using GraphQL_Net6.Entities.Models.Author;

namespace GraphQL_Net6.Entities.Context
{
    public class AuthorContextConfiguration : IEntityTypeConfiguration<Author>
    {
        private Guid[] _ids;

        public AuthorContextConfiguration(Guid[] ids)
        {
            _ids = ids;
        }

        public void Configure(EntityTypeBuilder<Author> builder)
        {
            builder
                .HasData(
                new Author
                {
                    Id = Guid.NewGuid(),
                    Name= "John Doe",
                    Description = "Freelance Novelist"                   
                },
                new Author
                {
                    Id = Guid.NewGuid(),
                    Name = "James Wayne",
                    Description = "Commercial Columist"
                },
                new Author
                {
                    Id = Guid.NewGuid(),
                    Name = "William Patrick",
                    Description = "Financila Analyst"
                }
           );
        }
    }
}
