﻿using GraphQL_Net6.Entities.Context;
using GraphQL_Net6.Entities.Models.Author;
using GraphQL_Net6.Entities.Models.Book;
using Microsoft.EntityFrameworkCore;

namespace GraphQL_Net6.Entities
{
    public class ApplicationDBContext : DbContext
    {
        public ApplicationDBContext(DbContextOptions options) : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            var ids = new Guid[] { Guid.NewGuid(), Guid.NewGuid() };
            modelBuilder.ApplyConfiguration(new AuthorContextConfiguration(ids));           
        }
        public DbSet<Author> Authors { get; set; }
        public DbSet<Book> Books { get; set; }
    
    }
}
