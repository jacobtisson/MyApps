﻿using Azure;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.Win32;
using MyWebAppToken.Data;
using MyWebAppToken.Data.Helpers;
using MyWebAppToken.Data.Models;
using MyWebAppToken.Data.ViewModels;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;

namespace MyWebAppToken.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthenticationController : ControllerBase
    {
        private readonly UserManager<User> _userManager;

        private readonly RoleManager<IdentityRole> _roleManager;

        private readonly AppDBContext _context;

        private readonly IConfiguration _configuration;

        private readonly TokenValidationParameters _tokenValidationParameters;

        public AuthenticationController(UserManager<User> userManager, RoleManager<IdentityRole> roleManager, AppDBContext context, IConfiguration configuration, TokenValidationParameters tokenValidationParameters)
        {
            _userManager = userManager;
            _roleManager = roleManager;
            _context = context;
            _configuration = configuration;
            _tokenValidationParameters = tokenValidationParameters;
        }

        [HttpPost("register-user")]
        public async Task<IActionResult> Register([FromBody] Register register)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }


            var userEmailExists = await _userManager.FindByEmailAsync(register.Email);
            if (userEmailExists != null)
            {
                return BadRequest($"User Email {register.Email} already exists");
            }

            var userNameExists = await _userManager.FindByNameAsync(register.UserName);
            if (userNameExists != null)
            {
                return BadRequest($"User Name {register.UserName} already exists");
            }

            User newUser = new User
            {
                FirstName = register.FirstName,
                LastName = register.LastName,
                Email = register.Email,
                UserName = register.UserName,
                Password = register.Password,
                EmailConfirmed = false,
                PhoneNumberConfirmed = false,
                TwoFactorEnabled = false,
                LockoutEnabled = false,
                AccessFailedCount = 0,
                SecurityStamp = Guid.NewGuid().ToString()
            };

            var result = await _userManager.CreateAsync(newUser, register.Password);

            if (result.Succeeded)
            {
                //Add Role
                switch (register.Role)
                {
                    case UserRoles.Manager:
                        await _userManager.AddToRoleAsync(newUser, UserRoles.Manager);
                        break;
                    case UserRoles.Student:
                        await _userManager.AddToRoleAsync(newUser, UserRoles.Student);
                        break;
                    default:
                        return BadRequest("UserRole given is not valid, please give Student or Manager");
                        break;
                }
                return Ok("User created");
            }
            else return BadRequest("User Could not be created");
        }

        [HttpPost("login-user")]
        public async Task<IActionResult> Login([FromBody] Login login)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest("Please Provide all Required Fields");
            }

            var userExists = await _userManager.FindByEmailAsync(login.Email);
            if (userExists != null && await _userManager.CheckPasswordAsync(userExists, login.Password))
            {
                var tokenValue = await GenerateJWTTokenAsync(userExists, null);
                return Ok(tokenValue);
            }
            return Unauthorized();
        }

        [HttpPost("refresh-token")]
        public async Task<IActionResult> RefreshToken([FromBody] TokenRequest tokenRequest)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest("Please, provide all required fields");
            }

            var result = await VerifyAndGenerateTokenAsync(tokenRequest);
            return Ok(result);
        }

        private async Task<AuthResult> VerifyAndGenerateTokenAsync(TokenRequest tokenRequest)
        {
            var jwtTokenHandler = new JwtSecurityTokenHandler();
            var storedToken = await _context.RefreshToken.FirstOrDefaultAsync(x => x.Token == tokenRequest.RefreshToken);
            var dbUser = await _userManager.FindByIdAsync(storedToken.UserId);

            try
            {
                var tokenCheckResult = jwtTokenHandler.ValidateToken(tokenRequest.Token, _tokenValidationParameters, out var validatedToken);

                return await GenerateJWTTokenAsync(dbUser, storedToken);
            }
            catch (SecurityTokenExpiredException)
            {
                if (storedToken.DateExpire >= DateTime.UtcNow)
                {
                    return await GenerateJWTTokenAsync(dbUser, storedToken);
                }
                else
                {
                    return await GenerateJWTTokenAsync(dbUser, null);
                }
            }
        }

        private async Task<AuthResult> GenerateJWTTokenAsync(User user, RefreshToken rToken)
        {
            var authClaims = new List<Claim>()
            {
                new Claim(ClaimTypes.Name, user.UserName),
                new Claim(ClaimTypes.NameIdentifier, user.Id),
                new Claim(JwtRegisteredClaimNames.Email, user.Email),
                new Claim(JwtRegisteredClaimNames.Sub, user.Email),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
            };

            //Add userRole Claims
            var userRoles = await _userManager.GetRolesAsync(user);
            var userClaims = new List<Claim>();
            foreach (var role in userRoles)
            {
                authClaims.Add(new Claim(ClaimTypes.Role, role));
            }

            var authSigningKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(_configuration["JWT:Secret"]));

            var token = new JwtSecurityToken(
                issuer: _configuration["JWT:Issuer"],
                audience: _configuration["JWT:Audience"],
                expires: DateTime.UtcNow.AddMinutes(1),
                claims: authClaims,
                signingCredentials: new SigningCredentials(authSigningKey, SecurityAlgorithms.HmacSha256));

            var jwtToken = new JwtSecurityTokenHandler().WriteToken(token);

            if (rToken != null)
            {
                var rTokenResponse = GetTokenResponse(jwtToken, rToken.Token, token.ValidTo);
                return rTokenResponse;
            }

            var refreshToken = new RefreshToken()
            {
                JwtId = token.Id,
                IsRevoked = false,
                DateAdded = DateTime.UtcNow,
                DateExpire = DateTime.UtcNow.AddMonths(1),
                Token = Guid.NewGuid().ToString() + "-" + Guid.NewGuid().ToString(),
                UserId = user.Id
            };

            var response = new AuthResult();
            //Update Token for Already Existing User             
            var storedToken = await _context.RefreshToken.FirstOrDefaultAsync(x => x.UserId == user.Id);
            if (storedToken != null)
            {
                storedToken.Token = Guid.NewGuid().ToString() + "-" + Guid.NewGuid().ToString();
                storedToken.JwtId = token.Id;
                storedToken.IsRevoked = false;
                storedToken.DateExpire = DateTime.UtcNow.AddMonths(1);
                await _context.SaveChangesAsync();
                response = GetTokenResponse(jwtToken, storedToken.Token, storedToken.DateExpire);                
            }
            else //Add Token for New Users
            {
                await _context.RefreshToken.AddAsync(refreshToken);
                await _context.SaveChangesAsync();
                response = GetTokenResponse(jwtToken, refreshToken.Token, token.ValidTo);                
            }
            return response;
        }

        private AuthResult GetTokenResponse(string jwtToken, string refreshToken, DateTime expiresAt)
        {
            var response = new AuthResult()
            {
                Token = jwtToken,
                RefreshToken = refreshToken,
                ExpiresAt = expiresAt
            };
            return response;
        }
    }
}
