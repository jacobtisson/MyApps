﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MyWebAppToken.Data.Helpers;
using System.Data;

namespace MyWebAppToken.Controllers
{
    [Authorize(Roles = UserRoles.Manager)]
    [Route("api/[controller]")]
    [ApiController]
    public class AdminController : ControllerBase
    {
        public AdminController()
        {
        }

        [HttpGet]
        public IActionResult Get()
        {
            return Ok("Welcome to AdminController");
        }
    }
}
