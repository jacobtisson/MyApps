﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using MyWebAppToken.Data.Models;

namespace MyWebAppToken.Data
{
    public class AppDBContext : IdentityDbContext<User>
    {
        public AppDBContext(DbContextOptions options) : base(options) { }
        
            public DbSet<RefreshToken> RefreshToken { get; set; }


    }
}
