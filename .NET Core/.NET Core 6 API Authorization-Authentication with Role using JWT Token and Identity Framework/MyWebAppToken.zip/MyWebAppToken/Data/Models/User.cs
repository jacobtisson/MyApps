﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;

namespace MyWebAppToken.Data.Models
{
    public class User : IdentityUser
    {        
       
        public string? FirstName { get; set; }
        public string? LastName { get; set; }       
        [Required]
        public string Password { get; set; }        
        public string? CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public string? ModifiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }

    }
}
