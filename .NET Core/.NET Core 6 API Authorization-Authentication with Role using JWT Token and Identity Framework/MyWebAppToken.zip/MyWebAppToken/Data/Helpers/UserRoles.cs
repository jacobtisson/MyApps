﻿namespace MyWebAppToken.Data.Helpers
{
    public class UserRoles
    {
        public const string Manager = "Manager";
        public const string Student = "Student";
    }
}
